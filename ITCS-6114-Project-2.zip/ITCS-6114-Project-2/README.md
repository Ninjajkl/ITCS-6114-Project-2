INSTRUCTIONS TO RUN

Download Project
Go to "ITCS-6114-Project-2\ITCS-6114-Project-2\"

Run "ITCS-6114-Project-2.exe"

OR if extracting from ZIP

Extract ITCS-6114-Project-2

Run "ITCS-6114-Project-2.exe"

A console should pop up and start running the program.


The main code for the project is located in Program.cs

The Graph Class is located in Graph.cs

The code for Dijkstra's Algorithm is located in ShortestPath.cs

The code for Prim's algorithm is located in MinSpanningTree.cs

The code to generate a graph is located in GenerateGraph.cs
